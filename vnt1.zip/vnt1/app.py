from flask import Flask, render_template, request

from cs50 import SQL

app = Flask(__name__)

db=SQL("sqlite:///data2.db")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/watch1", methods=["GET"])
def watch1():
    rows = db.execute("SELECT * FROM info")
    return render_template("watch1.html", rows=rows)

@app.route("/watch2", methods=["GET"])
def watch2():
    rows = db.execute("SELECT * FROM rank")
    return render_template("watch2.html", rows=rows)

@app.route("/home", methods=["GET"])
def home():
    return render_template("index.html")

@app.route("/dop1", methods=["GET"])
def dop1():
    return render_template("form.html",)

@app.route("/dop2", methods=["GET"])
def dop2():
    return render_template("form2.html")

@app.route("/fun", methods=["GET"])
def fun():
    nickname=request.args.get("nickname")
    game=request.args.get("game")
    sex=request.args.get("sex")
    roles = ""
    for number in range(1,6):
        buf=request.args.get("role{}".format(number))
        if buf!=None:
            roles+=buf+" "
    rank=request.args.get("rank")
    comment=request.args.get("comment")

    db.execute(f"INSERT INTO info (nickname,game,sex,role,rank,comment) VALUES ('{nickname}','{game}','{sex}','{roles}','{rank}','{comment}')")

    return render_template("index.html")

@app.route("/fun2", methods=["GET"])
def fun2():
    mmr=request.args.get("mmr")
    rank=request.args.get("rank")

    db.execute(f"INSERT INTO rank (mmr,rank) VALUES ('{mmr}','{rank}')")

    return render_template("index.html")